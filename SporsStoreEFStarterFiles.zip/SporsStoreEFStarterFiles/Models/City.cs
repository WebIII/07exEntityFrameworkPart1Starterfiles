﻿namespace SportsStore.Models
{
    public class City
    {
        public string Postalcode { get; set; }
        public string Name { get; set; }
    }
}